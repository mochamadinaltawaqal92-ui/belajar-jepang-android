package com.belajarjepang

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        sendNotification(context)
    }

    private fun sendNotification(context: Context) {
        val prefs = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val currentDay = prefs.getInt(MainActivity.KEY_CURRENT_DAY, 1)

        val messages = listOf(
            "今日も練習しましょう！ Yuk belajar Jepang hari ini! 🌸",
            "Sudah belajar huruf Jepang hari ini? ひらがな menunggumu! ✨",
            "5 menit saja! Latihan huruf Jepang sekarang 🗾",
            "Jangan sampai lupa belajar! カタカナ hari ini yuk 📚",
            "Konsisten adalah kunci! Buka pelajaran Jepang-mu 🎌"
        )
        val message = messages[(currentDay % messages.size)]

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, MainActivity.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🇯🇵 Belajar Jepang — Hari $currentDay")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setColor(0xC9A84C.toInt())
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(MainActivity.NOTIFICATION_ID, notification)
    }
}
