package com.belajarjepang

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import android.view.Window

class NotificationSettingsDialog(
    context: Context,
    private val currentEnabled: Boolean,
    private val currentHour: Int,
    private val currentMin: Int,
    private val onSave: (Boolean, Int, Int) -> Unit
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        setContentView(R.layout.dialog_notification_settings)

        val switchEnable = findViewById<Switch>(R.id.switch_enable_notif)
        val timePicker = findViewById<TimePicker>(R.id.time_picker)
        val btnSave = findViewById<Button>(R.id.btn_save_notif)
        val btnCancel = findViewById<Button>(R.id.btn_cancel_notif)

        switchEnable.isChecked = currentEnabled
        timePicker.setIs24HourView(true)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            timePicker.hour = currentHour
            timePicker.minute = currentMin
        } else {
            @Suppress("DEPRECATION")
            timePicker.currentHour = currentHour
            @Suppress("DEPRECATION")
            timePicker.currentMinute = currentMin
        }

        timePicker.isEnabled = currentEnabled
        switchEnable.setOnCheckedChangeListener { _, isChecked ->
            timePicker.isEnabled = isChecked
        }

        btnSave.setOnClickListener {
            val hour = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                timePicker.hour
            } else {
                @Suppress("DEPRECATION")
                timePicker.currentHour
            }
            val min = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                timePicker.minute
            } else {
                @Suppress("DEPRECATION")
                timePicker.currentMinute
            }
            onSave(switchEnable.isChecked, hour, min)
            dismiss()
        }

        btnCancel.setOnClickListener { dismiss() }
    }
}
