package com.belajarjepang

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.Toolbar
import org.json.JSONObject
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var prefs: SharedPreferences
    private var isDarkMode = false
    private var currentDay = 0

    companion object {
        const val CHANNEL_ID = "belajar_jepang_channel"
        const val NOTIFICATION_ID = 1001
        const val PREFS_NAME = "BelajarJepangPrefs"
        const val KEY_DARK_MODE = "dark_mode"
        const val KEY_NOTIF_ENABLED = "notif_enabled"
        const val KEY_NOTIF_HOUR = "notif_hour"
        const val KEY_NOTIF_MIN = "notif_minute"
        const val KEY_CURRENT_DAY = "current_day"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isDarkMode = prefs.getBoolean(KEY_DARK_MODE, false)

        // Apply dark mode to system UI
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            window.decorView.systemUiVisibility = 0
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        setContentView(R.layout.activity_main)

        // Setup toolbar
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Setup WebView
        webView = findViewById(R.id.webview)
        setupWebView()

        // Create notification channel
        createNotificationChannel()

        // Schedule notification if enabled
        if (prefs.getBoolean(KEY_NOTIF_ENABLED, true)) {
            scheduleNotification(
                prefs.getInt(KEY_NOTIF_HOUR, 19),
                prefs.getInt(KEY_NOTIF_MIN, 0)
            )
        }

        // Load the app
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true        // for localStorage (progress saving)
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        // Inject Android bridge
        webView.addJavascriptInterface(AndroidBridge(), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Keep all navigation inside WebView
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // Apply saved dark mode state to WebView
                val dm = if (isDarkMode) "true" else "false"
                webView.evaluateJavascript("setDarkMode($dm);", null)
                updateToolbarColor()
            }
        }

        webView.webChromeClient = WebChromeClient()

        // Handle back button inside WebView
        webView.setBackgroundColor(if (isDarkMode) Color.parseColor("#121218") else Color.parseColor("#faf7f2"))
    }

    // ================ ANDROID JAVASCRIPT INTERFACE ================
    inner class AndroidBridge {
        @JavascriptInterface
        fun onAction(action: String, dataJson: String) {
            try {
                val data = JSONObject(dataJson)
                runOnUiThread {
                    when (action) {
                        "pageChange" -> {
                            currentDay = data.optInt("day", 0)
                            prefs.edit().putInt(KEY_CURRENT_DAY, currentDay).apply()
                        }
                        "dayComplete" -> {
                            val day = data.optInt("day", 0)
                            Toast.makeText(
                                this@MainActivity,
                                "🎉 Hari $day selesai! おめでとう！",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // ================ TOOLBAR MENU ================
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        // Update dark mode icon
        menu.findItem(R.id.action_dark_mode)?.setIcon(
            if (isDarkMode) R.drawable.ic_light_mode else R.drawable.ic_dark_mode
        )
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_dark_mode -> {
                toggleDarkMode()
                true
            }
            R.id.action_notification -> {
                showNotificationSettings()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleDarkMode() {
        isDarkMode = !isDarkMode
        prefs.edit().putBoolean(KEY_DARK_MODE, isDarkMode).apply()
        webView.evaluateJavascript("setDarkMode($isDarkMode);", null)
        webView.setBackgroundColor(if (isDarkMode) Color.parseColor("#121218") else Color.parseColor("#faf7f2"))
        updateToolbarColor()
        invalidateOptionsMenu()
        Toast.makeText(
            this,
            if (isDarkMode) "🌙 Dark Mode aktif" else "☀️ Light Mode aktif",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun updateToolbarColor() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        if (isDarkMode) {
            toolbar.setBackgroundColor(Color.parseColor("#0d0d16"))
        } else {
            toolbar.setBackgroundColor(Color.parseColor("#1a1a2e"))
        }
        // Status bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = if (isDarkMode) Color.parseColor("#0d0d16") else Color.parseColor("#1a1a2e")
        }
    }

    private fun showNotificationSettings() {
        val isEnabled = prefs.getBoolean(KEY_NOTIF_ENABLED, true)
        val hour = prefs.getInt(KEY_NOTIF_HOUR, 19)
        val min = prefs.getInt(KEY_NOTIF_MIN, 0)

        val dialog = NotificationSettingsDialog(this, isEnabled, hour, min) { enabled, h, m ->
            prefs.edit()
                .putBoolean(KEY_NOTIF_ENABLED, enabled)
                .putInt(KEY_NOTIF_HOUR, h)
                .putInt(KEY_NOTIF_MIN, m)
                .apply()

            if (enabled) {
                scheduleNotification(h, m)
                Toast.makeText(this, "🔔 Pengingat diatur pukul ${String.format("%02d:%02d", h, m)}", Toast.LENGTH_SHORT).show()
            } else {
                cancelNotification()
                Toast.makeText(this, "🔕 Pengingat dimatikan", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    // ================ NOTIFICATIONS ================
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pengingat Belajar Jepang",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifikasi harian pengingat belajar Hiragana & Katakana"
                enableLights(true)
                lightColor = Color.parseColor("#c9a84c")
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun scheduleNotification(hour: Int, minute: Int) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, NOTIFICATION_ID, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            // If time already passed today, schedule for tomorrow
            if (timeInMillis < System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            cal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    private fun cancelNotification() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, NotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, NOTIFICATION_ID, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    // ================ BACK BUTTON ================
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
