-keep class com.belajarjepang.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
