# 🇯🇵 Belajar Jepang — Panduan Build APK

## Tentang Aplikasi
Aplikasi Android untuk belajar Hiragana & Katakana selama 30 hari.
Dikemas sebagai **WebView App** dari file HTML asli.

### Fitur:
- ✅ Semua 30 hari materi Hiragana & Katakana
- 🎯 Kuis interaktif & permainan cocokkan huruf
- 🌙 Dark Mode (tombol di toolbar)
- 🔔 Notifikasi harian pengingat belajar (bisa diatur waktunya)
- 📴 Mode Offline penuh (tidak butuh internet)
- 💾 Progress tersimpan otomatis (localStorage)

---

## Cara Build APK (3 Langkah)

### Prasyarat
- **Android Studio** versi terbaru → [download di developer.android.com/studio](https://developer.android.com/studio)
- **JDK 17** (sudah termasuk dalam Android Studio)

---

### Langkah 1 — Buka Proyek
1. Ekstrak file ZIP ini
2. Buka **Android Studio**
3. Pilih **File → Open**
4. Arahkan ke folder `BelajarJepang` → klik **OK**
5. Tunggu Gradle sync selesai (1-3 menit, butuh internet pertama kali)

---

### Langkah 2 — Build APK
**Cara Mudah (GUI):**
1. Klik menu **Build** di toolbar atas
2. Pilih **Build Bundle(s) / APK(s)**
3. Pilih **Build APK(s)**
4. Tunggu proses selesai
5. Klik notifikasi **"locate"** yang muncul di pojok kanan bawah

**Atau via Terminal:**
```bash
# Di folder BelajarJepang
./gradlew assembleDebug
```
APK berada di: `app/build/outputs/apk/debug/app-debug.apk`

---

### Langkah 3 — Install ke HP Android
**Cara 1 — USB:**
1. Aktifkan **Developer Options** di HP kamu
   - Buka Pengaturan → Tentang Ponsel → ketuk "Nomor Build" 7x
2. Aktifkan **USB Debugging**
3. Sambungkan HP ke komputer via USB
4. Di Android Studio: klik ▶️ (Run) atau tekan **Shift+F10**

**Cara 2 — Salin APK:**
1. Salin file `app-debug.apk` ke HP
2. Buka File Manager di HP
3. Tap file APK → Install
4. Jika ada peringatan "dari sumber tidak dikenal" → Izinkan

---

## Struktur Proyek
```
BelajarJepang/
├── app/
│   ├── src/main/
│   │   ├── java/com/belajarjepang/
│   │   │   ├── MainActivity.kt          ← Aktivitas utama + WebView
│   │   │   ├── NotificationReceiver.kt  ← Penerima alarm notifikasi
│   │   │   └── NotificationSettingsDialog.kt ← Dialog pengaturan notif
│   │   ├── assets/www/
│   │   │   └── index.html               ← Konten aplikasi (HTML asli)
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml    ← Layout toolbar + WebView
│   │   │   │   └── dialog_notification_settings.xml
│   │   │   ├── drawable/                ← Icon SVG (dark/light/notif)
│   │   │   ├── menu/main_menu.xml       ← Menu toolbar
│   │   │   ├── mipmap-*/                ← Icon launcher semua ukuran
│   │   │   └── values/                  ← strings, colors, styles
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## Cara Pakai Aplikasi

### Dark Mode
- Tap ikon 🌙 **bulan** di pojok kanan atas toolbar
- Tap lagi untuk kembali ke Light Mode ☀️

### Notifikasi Harian
- Tap ikon 🔔 **lonceng** di toolbar
- Aktifkan switch, pilih jam pengingat
- Tap **Simpan**
- Defaultnya: pukul 19.00 setiap hari

### Progress Belajar
- Progress tersimpan otomatis di storage HP
- Tidak akan hilang meski aplikasi ditutup

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Gradle sync gagal | Pastikan ada koneksi internet, klik "Retry" |
| Huruf Jepang tidak muncul | Install font Noto CJK di HP (biasanya sudah ada) |
| Notifikasi tidak muncul | Pastikan izin notifikasi diaktifkan di Pengaturan HP |
| Build error "SDK not found" | Buka SDK Manager di Android Studio, install Android 14 (API 34) |

---

## Spesifikasi Minimum HP
- Android 5.0 (Lollipop) atau lebih baru
- RAM: 1 GB
- Storage: ~10 MB
- Tidak butuh internet (offline penuh)

---

*Dibuat dengan ❤️ | Versi 1.0*
